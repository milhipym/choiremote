package com.ym.mvvn_2.dialog

import android.content.Context
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import com.ym.mvvn_2.MainActivity
import com.ym.mvvn_2.R

class LoadingDialog(context: MainActivity) : Dialog(context){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_loading)

        //외부 화면 터치했을 때 다이얼로그 종료되지 않게.
        setCanceledOnTouchOutside(false)

        //다이얼로그 배경 투명
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

    }

}


