package com.ym.mvvn_2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ServiceSelectActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_service_select)

        val customerBtn = findViewById<View>(R.id.customer) as Button
        customerBtn.setOnClickListener(this)

        val service1Btn = findViewById<View>(R.id.service1) as Button
        service1Btn.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        var url = String()
        var host = String()
        var serviceNm = String()
        Log.d(TAG, "onClick: $v")
        Log.d(TAG, "onClick: ${v.id}")
        if (v != null) {
            if(v.id == R.id.customer){
                host= "http://10.88.22.88:8300"
                url="/mobile/monitoring/"
                serviceNm="cusAgree"
                goMain(url, host, serviceNm)
            }else{
                Toast.makeText(this, "Service1입니다.", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun goMain(url: String, host: String, serviceNm : String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("URL", url)
        intent.putExtra("HOST", host)
        intent.putExtra("SERVICE_NAME", serviceNm)

        startActivity(intent)
        finish()
    }

    companion object{
        const val TAG = "CHOI"
    }
}