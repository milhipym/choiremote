package com.ym.mvvn_2.retrofit2.http

import com.google.gson.annotations.SerializedName

data class TestModel(
    val result: Map<String, String>? = null,
    val data: ArrayList<String>? = null
)

data class TestModelData(
    val result_cd: String? = null,
    val result_nm: String? = null
)

data class ApiRequestModel(
    val key : String? = null
)

data class ResponseDataModel(
    var result : Map<String, ResultData>? = null
)

data class ResultData(
    @SerializedName("grp_cnt")
    var grpCnt : Int? = null,
    @SerializedName("grp_data")
    var grpData: ArrayList<ResponseData>? = null
)

data class ResponseData(
    @SerializedName("grp_title")
    var grpTitle : String? = null,
    var data : ArrayList<String>? = null,
    @SerializedName("data_cnt")
    var dataCnt : String? = null,
    @SerializedName("grp_type")
    var grpType : String? = null,
    @SerializedName("grp_label")
    var grpLabel : String? = null
)