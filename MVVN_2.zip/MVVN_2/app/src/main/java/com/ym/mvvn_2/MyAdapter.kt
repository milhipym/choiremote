package com.ym.mvvn_2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.recycle_cardview_item.view.*

class MyAdapter() : RecyclerView.Adapter<MyAdapter.MyViewHolder>(){
    var card_nm_name = arrayOf("SAMSUNG", "KB국민", "Hyundai", "KEB Hana")
    var card_nb = arrayOf("5111254895786359", "1212548798565569", "8795698526324547", "4587985691254845")

    class MyViewHolder(itemview: View) : RecyclerView.ViewHolder(itemview){

        var card_nm : TextView = itemview.card_nm_name
        var card_nb_1 : TextView = itemview.card_nb_1
        var card_nb_2 : TextView = itemview.card_nb_2
        var card_nb_3 : TextView = itemview.card_nb_3
        var card_nb_4 : TextView = itemview.card_nb_4
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var v: View = LayoutInflater.from(parent.context).inflate(R.layout.recycle_cardview_item, parent, false)

        return MyViewHolder(v)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.card_nm.setText(card_nm_name.get(position))
        var card_nb_str = card_nb.get(position)
        var card_nb_str_1 = card_nb_str.substring(0,4)
        var card_nb_str_2 = card_nb_str.substring(4,8)
        var card_nb_str_3 = card_nb_str.substring(8,12)
        var card_nb_str_4 = card_nb_str.substring(12,16)
        holder.card_nb_1.setText(card_nb_str_1)
        holder.card_nb_2.setText(card_nb_str_2)
        holder.card_nb_3.setText(card_nb_str_3)
        holder.card_nb_4.setText(card_nb_str_4)
    }

    override fun getItemCount(): Int {
        return card_nm_name.size
    }
}