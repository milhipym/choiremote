package com.ym.mvvn_2.retrofit2.http

import android.util.Log
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

interface ApiInterface {

    @POST("{path}")
    @Headers("accept: application/json",
        "content-type: application/json")
    fun getData_post(
        @Body jsonParams: String
    ): Call<ResponseDataModel>

    @GET("{path}")
    @Headers("accept: application/json",
        "content-type: application/json")
    fun getData_get(@Path(value = "path", encoded = true)path : String): Call<ResponseBody>

    companion object{
        const val customerMonitoringKey = "leRMfiGXtp6laKD6C6MQSxgrv+DdFVp5WRhFejuew70="    //고객동의시스템 요청 KEY

        fun create(baseUrl : String): ApiInterface{
            var okHttpClient : OkHttpClient = OkHttpClient().newBuilder()
                .connectTimeout(10, TimeUnit.MINUTES)
                .readTimeout(10, TimeUnit.MINUTES)
                .writeTimeout(10, TimeUnit.MINUTES)
                .build()

            val gson : Gson = GsonBuilder().setLenient().create()
            Log.d("CHOI", "ApiInterface.kt create: BASE_URL[$baseUrl]")
            return Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
                .create(ApiInterface::class.java)
        }

    }
}