package com.ym.mvvn_2

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import com.ym.mvvn_2.dialog.LoadingDialog
import com.ym.mvvn_2.retrofit2.http.ApiInterface
import com.ym.mvvn_2.retrofit2.http.ApiInterface.Companion.customerMonitoringKey
import com.ym.mvvn_2.retrofit2.http.ApiRequestModel
import okhttp3.ResponseBody
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.lang.Exception
import kotlin.concurrent.thread
import kotlin.math.roundToInt
import kotlin.time.ExperimentalTime

class MainActivity : AppCompatActivity() {
    private lateinit var barChart : BarChart
    private lateinit var xAxis : XAxis
    private lateinit var yAxis : YAxis

    private lateinit var dialog: LoadingDialog

    private var serviceName = "";
    private var url    = "";
    private var host   = "";

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val intent = intent
        host = intent.getStringExtra("HOST").toString()
        url = intent.getStringExtra("URL").toString()
        serviceName = intent.getStringExtra("SERVICE_NAME").toString()

        //API Call
        val baseUrl = host+url
        val api = ApiInterface.create(baseUrl)
        showLogD("MainActivity.kt onCreate: baseUrl : $baseUrl")
        showLogD("MainActivity.kt onCreate: method : $serviceName")

        setContentView(R.layout.graph_view)

        showLogD("MainActivity.kt serviceName $serviceName")
        when(serviceName) {
            "cusAgree" -> {
                startMethod(api, serviceName)
            }
            else -> {
                showToastMsg("Service Name is not found!!!")
            }
        }

    }



    //private fun  BarChartGrapth(chartItem2: ArrayList<ChartData2>, displayname: String) {
    private fun  BarChartGrapth() {
        //lineChart2 = findViewById(R.id.chart_2)

        //STEP1. BarEntry 데이터 저장
        val entryList = mutableListOf<BarEntry>()
        entryList.add(BarEntry(0f, 1f))
        entryList.add(BarEntry(1f, 5f))
        entryList.add(BarEntry(2f, 1f))
        entryList.add(BarEntry(3f, 9f))
        entryList.add(BarEntry(4f, 11f))
        entryList.add(BarEntry(5f, 4f))
        entryList.add(BarEntry(6f, 9f))
        //STEP2. BarDataSet. BarEntry의 데이터를 토대로 막대그래프 셋팅
        val depenses = BarDataSet(entryList, "성공 건수")
        depenses.color = ColorTemplate.rgb("#ff7b22")
        //STEP3. BarData. 여러개의 BarDataSet을 설정하기 위함.
        //val data = BarData(depenses, depenses)
        val data = BarData(depenses)
        //STEP4. BarChart. xml에 연동.
        depenses.setDrawValues(false)
        depenses.valueTextSize = 2f
        depenses.formSize = 5f

        //그리드 라인 숨기기
        /*lineChart2.axisLeft.setDrawGridLines(false)
        val xAxis : XAxis = lineChart2.xAxis
        xAxis.setDrawGridLines(false)
        xAxis.setDrawAxisLine(false)
        //오른쪽 y축 좌표 제거
        lineChart2.axisRight.isEnabled = false
        //레전트 제거
        lineChart2.legend.isEnabled = false
        //차트 설명 제거
        lineChart2.description.isEnabled = false
        lineChart2.animateY(3000)

        xAxis.position= XAxis.XAxisPosition.BOTTOM
        xAxis.valueFormatter = MyAxisFormatter()

        lineChart2.data = data
        lineChart2.invalidate()*/
    }

    inner class MyAxisFormatter : ValueFormatter() {
        val day = arrayOf("월","화","수","목","금","토","일")
        override fun getFormattedValue(value: Float): String {
            return day[value.toInt()]
        }
    }

    inner class MyAxisFormatter2 : ValueFormatter() {
        private val day = arrayOf("5분전","4분전","3분전","2분전","1분전")
        override fun getFormattedValue(value: Float): String {
            return day[value.toInt()]
        }
    }

    inner class MyAxisFormatTime(xLabel : JSONArray) : ValueFormatter(){
        private val xLabelArr : JSONArray = xLabel
        
        override fun getAxisLabel(value: Float, axis: AxisBase): String {
            val xLabelList : ArrayList<String> = ArrayList()
            for(i in 0 until xLabelArr.length() step 1){
                xLabelList.add(xLabelArr.get(i) as String)
            }
            
            var position : Int = value.roundToInt()
            Log.d(TAG, "getAxisLabel: position >> $position  value $value")
            if(value > 1 && value < 2){
                position = 0;
            }else if(value > 2 && value < 3){
                position = 1;
            }else if(value > 3 && value < 4){
                position = 2;
            }else if(value > 4 && value <= 5){
                position = 3;
            }
            Log.d(TAG, "getAxisLabel: position : $position")
            if(position < xLabelList.size && position >= 0){
                return xLabelList[position]
                //return xLabelList.getOrNull(value.toInt()-1)?: value.toString()
            }
            return ""
        }
    }


    @OptIn(ExperimentalTime::class)
    private fun callApi(api : ApiInterface, method : String){
        showLogD("onDetailRequest: $method init")
        showLoadingDialog()
        //val requestParam = ApiRequestModel(key = customerMonitoringKey) //post일 때 바디 설정
        Thread{
            api.getData_get("$method.do").enqueue(object : Callback<ResponseBody>{
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>){
                    disableLoadingDialog()
                    if(response.isSuccessful){
                        try {
                            val resBody = response.body()!!.string() as String
                            showLogD("onResponse: resBody $resBody")

                            var resData = JSONObject(resBody)

                            val resultData  = resData.getJSONObject("result")
                            showLogD("onResponse: resultData[$resultData]")

                            val resultCd : String = resultData["resultCd"] as String
                            val resultNm : String = resultData["resultNm"] as String
                            showLogD("onResponse: resultCd [$resultCd]")
                            showLogD("onResponse: resultNm [$resultNm]")

                            showToastMsg(resultNm)
                            if(resultCd == "00"){
                                val data = resData.getJSONObject("data")
                                showLogD("onResponse: data   [ $data ]")

                                val dataList : JSONArray = data.getJSONArray("dataList") as JSONArray
                                val chartLocation : String = data.getString("chartLocation") as String

                                showLogD(dataList.toString())
                                showLogD(chartLocation)

                                callDrawGraph(dataList, chartLocation)
                            }else{
                                showLogD("데이터 가져오기 실패. 결과 코드:$resultCd")
                            }
                        }catch (t: Throwable){
                            showLogD("onResponse message: ${t.message.toString()}")
                            showLogD("onResponse cause: ${t.cause.toString()}")
                            showLogD("onResponse Throwable: $t")
                        }
                    }else{
                        showLogD("onResponse: response not success MethodName : $method")
                    }
                }
                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    disableLoadingDialog()
                    showLogD("onFailure message: ${t.message.toString()}")
                    showLogD("onFailure cause: ${t.cause.toString()}")
                    showLogD("onFailure Throwable: $t")
                }

            })
        }.start()
        disableLoadingDialog()
        try{
            Thread.sleep(50)
        }catch (e: Exception){
            e.printStackTrace()
        }
    }

    fun twiceDataChart(data1 : JSONArray, data2 : JSONArray,
                       firstDataName : String, secondDataName : String,
                       firstDataLabel : String, secondDataLabel : String,
                       xLabel : JSONArray){

        //lineChart1 = findViewById(R.id.chart_1)

        //STEP1. Entry 데이터 저장
        val entryList1 = ArrayList<BarEntry>()
        val entryList2 = ArrayList<BarEntry>()


        showLogD("twiceDataChart: data1[$data1]")
        showLogD("twiceDataChart: data2[$data2]")

        // data1.length()
        for(i in 0 until data1.length() step 1){
            Log.d(TAG, "twiceDataChart: data1[i]   " + data1[i])
            //entryList1.add(BarEntry(2.2f * i.toFloat(), i.toFloat()+1))
            entryList1.add(BarEntry(i.toFloat(), data1[i].toString().toFloat()))
        }
        // data2.length()
        for(i in 0 until data2.length() step 1){
            Log.d(TAG, "twiceDataChart: data2[i]   " + data2[i])
            entryList2.add(BarEntry(i.toFloat(), data2[i].toString().toFloat()))
            //entryList2.add(BarEntry(2.2f * i.toFloat(), i.toFloat()+1))
        }

        val dataSet1 = BarDataSet(entryList1, firstDataName)
        val dataSet2 = BarDataSet(entryList2, secondDataName)

        dataSet1.color = ColorTemplate.rgb("#FF0000")
        dataSet2.color = ColorTemplate.rgb("#0022FF")

        //x 축 설정
        //val xAxis : XAxis = lineChart1.xAxis
        xAxis.run {
            xAxis.valueFormatter = MyAxisFormatTime(xLabel)
            xAxis.setDrawLabels(true)
            
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.granularity = 1f  //1단위 만큼 간격
            xAxis.setDrawGridLines(false)   //격자

            xAxis.setCenterAxisLabels(true)
        }

        //y 축 설정
        //val yAxis : YAxis = lineChart1.axisLeft
        yAxis.run {
            textColor = ContextCompat.getColor(this@MainActivity, R.color.black)
        }

        //y축 오른쪽 설정
        /*val yAxisRight : YAxis = lineChart1.axisRight
        yAxisRight.run {
            //y축 활성화 제거
            yAxisRight.setDrawLabels(false)
            yAxisRight.setDrawAxisLine(false)
            yAxisRight.setDrawGridLines(true)
        }

        lineChart1.run {
            //라인차트 최대로 보여질 x축 데이터
            lineChart1.setTouchEnabled(true)
            lineChart1.setPinchZoom(true) //핀치줌
            lineChart1.setScaleEnabled(true) //확대

            //lineChart1.setVisibleXRangeMaximum(0.1f)
            //lineChart1.setVisibleXRange(5f, 5f)

            lineChart1.setMaxVisibleValueCount(6)
            //가장 최근에 추가한 데이터의 위치로 이동처리
            //lineChart1.moveViewToX(dataSet1.entryCount.toFloat())

            //Description 삭제
            lineChart1.description = null

            val data = BarData(dataSet1, dataSet2)
            data.barWidth = 0.4f
            lineChart1.data = data

            lineChart1!!.groupBars(0f, 0.2f, 0.02f)
            lineChart1.setFitBars(true)

            lineChart1.invalidate()
        }*/



        /*val data = BarData(dataSet1, dataSet2)
        lineChart1.data = data
        lineChart1!!.groupBars(0.0f, 0.2f, 0.02f)
        lineChart1.setMaxVisibleValueCount(100)
        lineChart1.setVisibleXRangeMaximum(24f)

        lineChart1.invalidate()*/
    }

    companion object {
        const val TAG = "CHOI"
    }

    private fun changeDP(value: Int): Int {
        var displayMetrics = resources.displayMetrics
        return (value * displayMetrics.density).roundToInt()
    }

    //dialog 활성화
    private fun showLoadingDialog(){
        dialog = LoadingDialog(this)
        dialog.show()
    }

    //dialog 비활성화
    private fun disableLoadingDialog(){
        Log.e("CHOI","disableLoadingDialog()");
        dialog.dismiss()
    }

    private fun startMethod(api : ApiInterface, serviceNm : String){
        var methodArr : List<String> = emptyList()
        when(serviceNm){
            "cusAgree" -> {
                methodArr = listOf(
                    "getAllSmsSuccCnt"
                    ,"getSmsSuccTopFiveCnt"
                    ,"getTimeSmsSuccCnt"
                    ,"getDriverStatus"
                    ,"getKakaoSmsCnt"
                )
                for(method in methodArr) {
                   callApi(api, method)
                }
            }
        }
    }


    private fun showLogD(data : String){
        Log.d(TAG, "$data")
    }

    private fun showToastMsg(data: String){
        Toast.makeText(this, data, Toast.LENGTH_SHORT).show()
    }

    private fun callDrawGraph(dataList : JSONArray, chartLocation : String){
        when(chartLocation){
            "FIRST" -> {
                showLogD("FIRST GRAPH INIT!!!")
                goFirstChart(dataList)
            }
            "SECOND" -> {
                showLogD("SECOND GRAPH INIT!!!")
                goSecondChart(dataList)
            }
            "THIRD" -> {
                showLogD("THIRD GRAPH INIT!!!")
                goThirdChart(dataList)
            }
            "FOURTH" -> {
                showLogD("FOURTH GRAPH INIT!!!")
                goFourthChart(dataList)
            }
            "FIFTH" -> {
                showLogD("FIFTH GRAPH INIT!!!")
                goFifthChart(dataList)
            }
            else -> {
                showToastMsg("Not found chartLocation!!!!")
            }
        }
    }

    private fun goFifthChart(dataList: JSONArray) {
        barChart = findViewById(R.id.graph_five_ly)
    }

    private fun goFourthChart(dataList: JSONArray) {
        barChart = findViewById(R.id.graph_four_graph)
    }

    private fun goThirdChart(dataList: JSONArray) {
        barChart = findViewById(R.id.graph_three_graph)
    }

    private fun goSecondChart(dataList: JSONArray) {
        barChart = findViewById(R.id.graph_two_graph)
    }

    private fun goFirstChart(dataList: JSONArray) {
        barChart = findViewById(R.id.graph_one_ly)
        initSettingBarChart(barChart)
        setBarEntry(dataList)

    }

    private fun initSettingBarChart(barChart : BarChart){
        barChart.setBackgroundColor(Color.parseColor("#F2E6E6FA"))
        barChart.description.isEnabled = false // description 표시하지 않기
        barChart.setTouchEnabled(true) // 그래프 터치 가능
        barChart.isDragXEnabled = true // X축으로 드래그 가능
        barChart.isDragYEnabled = false // Y축으로 드래그 불가능
        barChart.setScaleEnabled(false) // 확대 불가능
        barChart.setPinchZoom(true) // pinch zoom 가능 (손가락으로 확대축소하는거)
        barChart.setVisibleXRange(5f, 5f) // 최대 x좌표 기준으로 몇개를 보여줄지 (최소값, 최대값)
        barChart.animateX(1000) //X축 애니메이션
        barChart.animateY(1500) //Y축 애니메이션

        setXYgraphStyle()
    }


    /*
    * #2. X축, Y축 스타일
    * XAxis, YAxis
    * */
    private fun setXYgraphStyle() {
        xAxis = barChart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM // X축을 그래프 아래로 위치하기
        xAxis.textSize = 10f // 레이블 텍스트 사이즈
        xAxis.textColor = Color.BLACK // 레이블 텍스트 색
        xAxis.axisLineColor = Color.BLACK // 축 색
        xAxis.setDrawAxisLine(false) // 그래프 뒷 배경의 그리드 표시하지 않기
        xAxis.setDrawGridLines(false)
        barChart.axisRight.isEnabled = false // Y축 오른쪽 보이지않게
        barChart.axisLeft.isEnabled = false // X축 오른쪽 보이지않게
        yAxis = barChart.axisLeft // Y축 왼쪽셋팅
        xAxis.textSize = 10f
        yAxis.textColor = Color.BLACK
        yAxis.axisLineColor = Color.BLACK
        yAxis.setDrawAxisLine(false)
        yAxis.setDrawGridLines(false)
        //yAxis.setAxisMaximum(1f);
        //yAxis.setAxisMinimum(0f);

    }

    /*
    * #3. 데이타 수집 및 스타일
    * BarEntry - X,Y 데이터 BarEntry(x,y) 담기 y값은 float
    * BarDataSet - Bar 데이터 스타일
    * */
    private fun setBarEntry(dataList : JSONArray) {
        val entries = ArrayList<BarEntry>()


        /*for(i in dataList) {
            entries.add(BarEntry(24, 1726))
            entries.add(BarEntry(25, 1236))
            entries.add(BarEntry(26, 14083))
            entries.add(BarEntry(27, 15670))
            entries.add(BarEntry(28, 17582))
            entries.add(BarEntry(29, 21037))
            entries.add(BarEntry(30, 6623))
        }
        val title = "전자사명 완료건수"
        barDataSet = BarDataSet(entries, title)
        barDataSet.setColor(Color.parseColor("#9370DB"))
        barDataSet.setDrawIcons(false)
        barDataSet.setDrawValues(true)
        //데이터값 스트링 변경
        setSyncDataAndGraph()*/
    }

    /*
    * #4. 데이터 + 그래프 싱크
    * */
    /*fun setSyncDataAndGraph() {
        val barData = BarData(barDataSet)
        barData.barWidth = 0.5f
        barData.setValueTextSize(5f)
        barChart.setData(barData) // BarData를 실제 barchart에 전달
        barChart.invalidate() // 갱신
    }
*/

}

